using Fasilkom_Point;
using Login;
using Microsoft.VisualBasic.Logging;

namespace Halaman_Poin_Mahasiswa
{
    public partial class BerandaTU : Form
    {
        public BerandaTU()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) 
        {
            DialogResult result = MessageBox.Show("Apakah Anda yakin ingin logout?", "Konfirmasi Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Halaman HalamanLogin = new Halaman();
                HalamanLogin.Show();
                this.Hide();
                
            }
            else if (result == DialogResult.No) 
            {
                
            }
        }
    }
}
